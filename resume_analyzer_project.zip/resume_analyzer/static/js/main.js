/**
 * ResumeAI — Frontend Controller
 * Handles form submission, tab switching, drag-and-drop,
 * and dynamic rendering of analysis results.
 */

'use strict';

// ── DOM References ─────────────────────────────────────────────────────────────
const analyzeForm      = document.getElementById('analyzeForm');
const analyzeBtn       = document.getElementById('analyzeBtn');
const btnText          = analyzeBtn.querySelector('.btn-text');
const btnLoading       = analyzeBtn.querySelector('.btn-loading');
const resultsPlaceholder = document.getElementById('resultsPlaceholder');
const resultsContent   = document.getElementById('resultsContent');
const errorState       = document.getElementById('errorState');
const errorMsg         = document.getElementById('errorMsg');

// ── Tab System ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${tab}`).classList.add('active');
  });
});

// ── File Drag & Drop ───────────────────────────────────────────────────────────
const dropzone  = document.getElementById('dropzone');
const fileInput = document.getElementById('resumeFile');
const dzFilename = document.getElementById('dzFilename');

// Click anywhere on dropzone triggers file picker
dropzone.addEventListener('click', e => {
  if (!e.target.closest('label')) fileInput.click();
});

fileInput.addEventListener('change', () => {
  if (fileInput.files.length > 0) {
    dzFilename.textContent = `✓ ${fileInput.files[0].name}`;
    dropzone.style.borderColor = 'var(--accent)';
  }
});

dropzone.addEventListener('dragover', e => {
  e.preventDefault();
  dropzone.classList.add('dragging');
});

dropzone.addEventListener('dragleave', () => {
  dropzone.classList.remove('dragging');
});

dropzone.addEventListener('drop', e => {
  e.preventDefault();
  dropzone.classList.remove('dragging');
  const files = e.dataTransfer.files;
  if (files.length > 0) {
    fileInput.files = files;            // assign dropped file
    dzFilename.textContent = `✓ ${files[0].name}`;
    dropzone.style.borderColor = 'var(--accent)';
  }
});

// ── Form Submission ────────────────────────────────────────────────────────────
analyzeForm.addEventListener('submit', async e => {
  e.preventDefault();

  // Basic validation
  const jd    = document.getElementById('jobDescription').value.trim();
  const file  = fileInput.files[0];
  const pasted = document.getElementById('resumeText').value.trim();
  const activeTab = document.querySelector('.tab-btn.active').dataset.tab;

  if (!jd) { return showError('Please enter a job description.'); }
  if (activeTab === 'upload' && !file) { return showError('Please upload a resume file.'); }
  if (activeTab === 'paste' && !pasted) { return showError('Please paste your resume text.'); }

  setLoading(true);
  hideError();
  hideResults();

  const formData = new FormData(analyzeForm);
  // Remove opposite input so server doesn't get confused
  if (activeTab === 'upload') formData.delete('resume_text');
  else                        formData.delete('resume_file');

  try {
    const res  = await fetch('/analyze', { method: 'POST', body: formData });
    const data = await res.json();

    if (!res.ok || data.error) {
      throw new Error(data.error || 'Analysis failed. Please try again.');
    }

    renderResults(data);

    // Smooth scroll to results on mobile
    if (window.innerWidth < 1024) {
      document.getElementById('resultsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

  } catch (err) {
    showError(err.message);
  } finally {
    setLoading(false);
  }
});

// ── Results Renderer ───────────────────────────────────────────────────────────
function renderResults(data) {
  // Score ring animation
  const score     = data.match_score;
  const grade     = data.match_grade;
  const ringCirc  = 326.73;
  const offset    = ringCirc - (score / 100) * ringCirc;

  const ringFill   = document.getElementById('ringFill');
  const scoreNum   = document.getElementById('scoreNumber');
  const scoreLabel = document.getElementById('scoreLabel');
  const scoreGrade = document.getElementById('scoreGrade');

  ringFill.style.stroke           = grade.color;
  ringFill.style.strokeDashoffset = offset;
  scoreNum.textContent            = `${score}%`;
  scoreLabel.textContent          = grade.label;
  scoreGrade.textContent          = grade.letter + ' — ' + grade.label;
  scoreGrade.style.color          = grade.color;
  scoreGrade.style.background     = hexToRgba(grade.color, 0.1);

  // Stats row
  const s = data.stats;
  document.getElementById('scoreStats').innerHTML = `
    <div class="ss-item"><div class="ss-val">${s.total_jd_skills}</div><div class="ss-lbl">JD Skills</div></div>
    <div class="ss-item"><div class="ss-val" style="color:var(--accent)">${s.matched_count}</div><div class="ss-lbl">Matched</div></div>
    <div class="ss-item"><div class="ss-val" style="color:var(--accent-3)">${s.missing_count}</div><div class="ss-lbl">Missing</div></div>
  `;

  // Matched skills
  const matchedEl = document.getElementById('matchedSkills');
  document.getElementById('matchedCount').textContent = data.matched_skills.length;
  matchedEl.innerHTML = data.matched_skills.length
    ? data.matched_skills.map((s, i) =>
        `<span class="skill-tag matched" style="animation-delay:${i * 0.04}s">${s}</span>`
      ).join('')
    : '<span style="color:var(--text-3);font-size:13px">No skills matched yet.</span>';

  // Missing skills
  const missingEl = document.getElementById('missingSkills');
  document.getElementById('missingCount').textContent = data.missing_skills.length;
  missingEl.innerHTML = data.missing_skills.length
    ? data.missing_skills.map((s, i) =>
        `<span class="skill-tag missing" style="animation-delay:${i * 0.04}s">${s}</span>`
      ).join('')
    : '<span style="color:var(--accent);font-size:13px">🎉 No missing skills detected!</span>';

  // Keyword Coverage
  const kwGrid = document.getElementById('keywordGrid');
  const kw = data.keyword_highlights;
  kwGrid.innerHTML = Object.entries(kw).map(([skill, present], i) =>
    `<span class="kw-tag ${present ? 'present' : 'absent'}"
      style="animation-delay:${i*0.03}s"
      title="${present ? 'Found in resume' : 'Missing from resume'}"
    >${present ? '✓' : '✗'} ${skill}</span>`
  ).join('') || '<span style="color:var(--text-3);font-size:13px">No keywords detected.</span>';

  // Suggestions
  const suggList = document.getElementById('suggestionsList');
  suggList.innerHTML = data.suggestions.length
    ? data.suggestions.map((s, i) => `
        <li style="animation-delay:${i * 0.06}s">
          <span class="sugg-num">${String(i+1).padStart(2,'0')}</span>
          <span>${s}</span>
        </li>`
      ).join('')
    : '<li><span>Your resume looks great — no major improvements needed!</span></li>';

  // Show results
  resultsPlaceholder.classList.add('hidden');
  resultsContent.classList.remove('hidden');
}

// ── UI Helpers ─────────────────────────────────────────────────────────────────
function setLoading(on) {
  analyzeBtn.disabled = on;
  btnText.classList.toggle('hidden', on);
  btnLoading.classList.toggle('hidden', !on);
}

function hideResults() {
  resultsContent.classList.add('hidden');
  resultsPlaceholder.classList.remove('hidden');
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorState.classList.remove('hidden');
  resultsPlaceholder.classList.add('hidden');
  resultsContent.classList.add('hidden');
}

function hideError() {
  errorState.classList.add('hidden');
}

function hexToRgba(hex, alpha) {
  // Supports 3 or 6 digit hex; returns rgba(...) string for inline styles
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return `rgba(0,245,160,${alpha})`;
  const [, r, g, b] = result;
  return `rgba(${parseInt(r,16)},${parseInt(g,16)},${parseInt(b,16)},${alpha})`;
}
