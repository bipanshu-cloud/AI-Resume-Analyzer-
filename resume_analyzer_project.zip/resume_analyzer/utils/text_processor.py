"""
utils/text_processor.py
========================
Cleans and preprocesses text for NLP analysis:
  - Lowercasing
  - Tokenisation
  - Stop-word removal
  - Punctuation removal
  - Lemmatisation (spaCy) with NLTK fallback
"""

import re
import string
from typing import List


# ── Stop-word list (NLTK / built-in fallback) ─────────────────────────────────

_BUILTIN_STOPWORDS = {
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're",
    "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he',
    'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's",
    'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which',
    'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are',
    'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do',
    'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because',
    'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against',
    'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
    'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
    'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how',
    'all', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no',
    'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't',
    'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now', 'd', 'll',
    'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn', "couldn't",
    'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't",
    'haven', "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn',
    "mustn't", 'needn', "needn't", 'shan', "shan't", 'shouldn', "shouldn't",
    'wasn', "wasn't", 'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't",
    # Resume-specific filler words
    'responsible', 'responsibilities', 'worked', 'work', 'experience', 'years',
    'year', 'team', 'strong', 'excellent', 'good', 'knowledge', 'ability',
    'skills', 'skill', 'including', 'ability', 'using', 'use', 'used',
}


class TextProcessor:
    """NLP preprocessing pipeline for resume and job-description text."""

    def __init__(self):
        self._nlp       = None   # spaCy model (lazy-loaded)
        self._stopwords = self._load_stopwords()

    # ── Public API ────────────────────────────────────────────────────────────

    def preprocess(self, text: str) -> str:
        """
        Full preprocessing pipeline → returns a clean, space-joined token string
        suitable for TF-IDF vectorisation.

        Steps:
          1. Lowercase
          2. Remove URLs, emails, phone numbers
          3. Remove punctuation / special characters
          4. Tokenise
          5. Remove stopwords and short tokens
          6. Lemmatise (spaCy preferred, simple stemmer fallback)
        """
        if not text:
            return ''

        text = text.lower()
        text = self._remove_noise(text)
        tokens = self._tokenize(text)
        tokens = self._remove_stopwords(tokens)
        tokens = self._lemmatize(tokens)
        tokens = [t for t in tokens if len(t) > 1]   # drop single chars
        return ' '.join(tokens)

    def get_tokens(self, text: str) -> List[str]:
        """Return the list of cleaned tokens (instead of a joined string)."""
        return self.preprocess(text).split()

    # ── Private Helpers ───────────────────────────────────────────────────────

    def _load_stopwords(self) -> set:
        """Try NLTK stopwords first, fall back to built-in set."""
        try:
            from nltk.corpus import stopwords
            import nltk
            try:
                return set(stopwords.words('english')) | _BUILTIN_STOPWORDS
            except LookupError:
                nltk.download('stopwords', quiet=True)
                return set(stopwords.words('english')) | _BUILTIN_STOPWORDS
        except ImportError:
            return _BUILTIN_STOPWORDS

    def _remove_noise(self, text: str) -> str:
        """Strip URLs, emails, phone numbers, and non-alphabetic characters."""
        text = re.sub(r'http\S+|www\.\S+', ' ', text)           # URLs
        text = re.sub(r'\S+@\S+\.\S+', ' ', text)               # emails
        text = re.sub(r'\+?\d[\d\s\-().]{7,}\d', ' ', text)     # phone numbers
        text = re.sub(r'[^a-z\s\+#]', ' ', text)                # keep letters, +, #
        text = re.sub(r'\s+', ' ', text)                         # collapse spaces
        return text.strip()

    def _tokenize(self, text: str) -> List[str]:
        """Simple whitespace tokeniser."""
        return text.split()

    def _remove_stopwords(self, tokens: List[str]) -> List[str]:
        """Filter out stop words."""
        return [t for t in tokens if t not in self._stopwords]

    def _lemmatize(self, tokens: List[str]) -> List[str]:
        """
        Lemmatise tokens.
        Uses spaCy if available, otherwise applies a naive suffix-stripping fallback.
        """
        # Try spaCy
        if self._nlp is None:
            self._nlp = self._load_spacy()

        if self._nlp:
            doc = self._nlp(' '.join(tokens))
            return [token.lemma_ for token in doc]

        # Fallback: lightweight rule-based stemmer
        return [self._simple_stem(t) for t in tokens]

    def _load_spacy(self):
        """Lazy-load a spaCy model (small English model preferred)."""
        try:
            import spacy
            for model in ('en_core_web_sm', 'en'):
                try:
                    return spacy.load(model, disable=['parser', 'ner'])
                except OSError:
                    continue
        except ImportError:
            pass
        return None

    def _simple_stem(self, word: str) -> str:
        """
        Naive rule-based stemmer to reduce common English suffixes.
        Not as accurate as spaCy lemmatisation, but dependency-free.
        """
        suffixes = ['ing', 'tion', 'tions', 'ized', 'ises', 'ise',
                    'ized', 'izes', 'ize', 'ment', 'ments', 'er', 'ers',
                    'ed', 'ly', 'ies', 'ied', 'ness']
        for suffix in suffixes:
            if word.endswith(suffix) and len(word) - len(suffix) > 3:
                return word[:-len(suffix)]
        return word
