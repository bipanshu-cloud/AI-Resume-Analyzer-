"""
utils/suggestion_engine.py
===========================
Generates actionable, personalised improvement suggestions based on:
  - Missing skills
  - Overall match score
  - Resume content patterns
  - Job description signals
"""

import re
from typing import List, Set


# ── Suggestion templates keyed by category / condition ────────────────────────

_SCORE_SUGGESTIONS = {
    'very_low': [
        "Your resume needs significant alignment with this role. Consider a targeted rewrite.",
        "Focus on adopting the exact terminology used in the job description.",
        "Research the company and role in depth, then reframe your experience around their needs.",
    ],
    'low': [
        "Highlight projects that are directly relevant to the listed responsibilities.",
        "Add a 'Technical Skills' or 'Core Competencies' section near the top of your resume.",
        "Quantify your achievements with metrics (e.g., 'Reduced load time by 40%').",
    ],
    'moderate': [
        "Mirror the language in the job description throughout your resume.",
        "Expand your experience bullets to cover responsibilities listed in the JD.",
        "Consider adding a brief professional summary that targets this specific role.",
    ],
    'good': [
        "You're a strong candidate! Fine-tune your bullet points to match JD keywords more precisely.",
        "Ensure your most relevant experiences are featured in the top third of your resume.",
        "Tailor your professional summary to directly address the role's key requirements.",
    ],
    'excellent': [
        "Great match! Proofread for grammar/formatting to make a polished impression.",
        "Prepare specific stories (STAR method) for each major skill listed in the JD.",
        "Consider requesting an informational interview to further demonstrate your enthusiasm.",
    ],
}

_SKILL_SUGGESTIONS = {
    "docker":          "Add a project showcasing containerisation with Docker (e.g., Dockerising a Flask/Node app).",
    "kubernetes":      "Include experience or a side project deploying apps with Kubernetes or Helm charts.",
    "aws":             "Obtain AWS Cloud Practitioner certification and deploy at least one project to AWS.",
    "azure":           "Explore Azure Fundamentals and deploy a small project to Azure App Service.",
    "gcp":             "Try Google Cloud's free tier and deploy a sample app to Cloud Run or GKE.",
    "machine learning":"Add an ML project (e.g., a Kaggle competition or personal dataset analysis) to GitHub.",
    "deep learning":   "Build a neural network project using PyTorch or TensorFlow and publish it.",
    "python":          "Strengthen Python by building a portfolio project (API, automation, or data pipeline).",
    "react":           "Build a React single-page application and host it on GitHub Pages or Vercel.",
    "typescript":      "Migrate an existing JavaScript project to TypeScript to demonstrate type safety skills.",
    "graphql":         "Replace a REST endpoint in a personal project with a GraphQL schema.",
    "rest api":        "Document a REST API you've built using Swagger/OpenAPI.",
    "microservices":   "Design and deploy a small microservices system (e.g., with Docker Compose).",
    "postgresql":      "Add a PostgreSQL-backed project to your portfolio (schema, queries, migrations).",
    "mongodb":         "Build a CRUD application using MongoDB and Mongoose/PyMongo.",
    "redis":           "Use Redis for caching in an existing project and document the performance gains.",
    "git":             "Maintain an active GitHub profile with clean commit history and READMEs.",
    "agile":           "Mention sprint planning, standups, or retrospectives if you've worked in agile teams.",
    "ci/cd":           "Set up a GitHub Actions or GitLab CI pipeline for one of your projects.",
    "terraform":       "Provision cloud infrastructure-as-code using Terraform (even locally with LocalStack).",
    "linux":           "Document your Linux/bash experience and include relevant shell scripts on GitHub.",
    "unit testing":    "Add unit tests (pytest / Jest) to an existing project to reach 80%+ coverage.",
    "scrum":           "Highlight any experience as a Scrum Master, developer, or PO in a scrum team.",
    "nlp":             "Implement a text-classification or sentiment-analysis project using spaCy or Transformers.",
    "data analysis":   "Publish a Jupyter Notebook analysing a public dataset on GitHub or Kaggle.",
    "sql":             "Complete advanced SQL exercises on LeetCode or Mode Analytics.",
    "spark":           "Build an ETL pipeline using PySpark on a public dataset.",
    "communication":   "Highlight presentations, reports, or cross-functional collaborations in your bullets.",
    "leadership":      "Mention team lead roles, mentoring, or leading a project initiative.",
}

_GENERAL_SUGGESTIONS = [
    "Use bullet points that start with strong action verbs (Designed, Built, Optimised, Led).",
    "Keep your resume to 1–2 pages; focus on the last 10 years of experience.",
    "Include a link to your GitHub, LinkedIn, or portfolio to showcase real work.",
    "Use a clean, ATS-friendly format — avoid tables, images, or multi-column layouts.",
    "Run your resume through a spell-checker and ask a peer to review it.",
    "Tailor your resume for each application rather than using a single generic version.",
]


class SuggestionEngine:
    """Generates actionable, prioritised suggestions for improving a resume."""

    def generate_suggestions(
        self,
        missing_skills: Set[str],
        match_score: float,
        resume_text: str,
        job_description: str,
    ) -> List[str]:
        """
        Build a prioritised list of suggestions (≤ 10 items).

        Parameters
        ----------
        missing_skills : Set[str]
            Skills present in JD but absent in resume.
        match_score : float
            Computed match percentage (0–100).
        resume_text : str
            Raw resume text (for pattern checks).
        job_description : str
            Raw job description text.

        Returns
        -------
        List[str]
            Ordered list of suggestion strings.
        """
        suggestions: List[str] = []

        # 1. Score-based advice
        suggestions += self._score_suggestions(match_score)

        # 2. Skill-specific advice
        suggestions += self._skill_suggestions(missing_skills)

        # 3. Resume structural checks
        suggestions += self._structural_checks(resume_text)

        # 4. General best practices (always include a couple)
        suggestions += _GENERAL_SUGGESTIONS[:2]

        # Deduplicate while preserving order
        seen: set = set()
        unique: List[str] = []
        for s in suggestions:
            if s not in seen:
                seen.add(s)
                unique.append(s)

        return unique[:10]  # cap at 10 suggestions

    # ── Private Helpers ───────────────────────────────────────────────────────

    def _score_suggestions(self, score: float) -> List[str]:
        if score < 35:
            return _SCORE_SUGGESTIONS['very_low'][:2]
        elif score < 50:
            return _SCORE_SUGGESTIONS['low'][:2]
        elif score < 65:
            return _SCORE_SUGGESTIONS['moderate'][:2]
        elif score < 80:
            return _SCORE_SUGGESTIONS['good'][:2]
        else:
            return _SCORE_SUGGESTIONS['excellent'][:2]

    def _skill_suggestions(self, missing_skills: Set[str]) -> List[str]:
        """Return specific suggestions for known missing skills (up to 5)."""
        tips: List[str] = []
        for skill in sorted(missing_skills):
            tip = _SKILL_SUGGESTIONS.get(skill.lower())
            if tip:
                tips.append(tip)
            if len(tips) >= 5:
                break
        # Generic fallback for unrecognised missing skills
        unrecognised = [s for s in sorted(missing_skills) if s not in _SKILL_SUGGESTIONS]
        if unrecognised and len(tips) < 5:
            skills_str = ', '.join(unrecognised[:4])
            tips.append(
                f"Gain hands-on experience with: {skills_str} — add projects or "
                f"online certifications to demonstrate proficiency."
            )
        return tips

    def _structural_checks(self, resume_text: str) -> List[str]:
        """Flag missing sections or common resume weaknesses."""
        tips: List[str] = []
        text_lower = resume_text.lower()

        # Check for quantified achievements
        if not re.search(r'\d+\s*%|\d+x|\$\s*\d+|\d+\s*(million|billion|k\b)', text_lower):
            tips.append(
                "Add quantified achievements — numbers make impact tangible "
                "(e.g., 'Improved API response time by 35%')."
            )

        # Check for a professional summary
        if not re.search(r'\b(summary|objective|profile|about me)\b', text_lower):
            tips.append(
                "Add a 3–4 line professional summary at the top of your resume "
                "that speaks directly to the role."
            )

        # Check for GitHub / LinkedIn / portfolio
        if not re.search(r'github\.com|linkedin\.com|portfolio|behance\.net', text_lower):
            tips.append(
                "Include links to your GitHub profile, LinkedIn, or an online portfolio."
            )

        # Check for certifications
        if not re.search(r'\b(certif|certified|certification|aws|gcp|azure|pmp|cka)\b', text_lower):
            tips.append(
                "Consider adding relevant certifications to strengthen your credentials "
                "(e.g., AWS, Google Cloud, PMP)."
            )

        return tips
