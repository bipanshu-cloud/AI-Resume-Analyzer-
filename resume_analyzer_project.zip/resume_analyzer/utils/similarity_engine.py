"""
utils/similarity_engine.py
===========================
Computes a semantic similarity score between a resume and a job description.

Primary method : TF-IDF + cosine similarity (scikit-learn)
Bonus method   : Basic ML scoring using additional lexical features
"""

import math
import re
from typing import Optional


class SimilarityEngine:
    """
    Computes match percentage between preprocessed resume and JD text.

    Two scoring modes:
      - `tfidf`  (default) — fast, interpretable TF-IDF cosine similarity.
      - `hybrid` — blends TF-IDF with keyword overlap and length features.
    """

    def __init__(self, mode: str = 'hybrid'):
        self.mode       = mode
        self._vectorizer = None   # lazy-initialised sklearn TF-IDF vectorizer

    # ── Public API ────────────────────────────────────────────────────────────

    def compute_similarity(
        self, processed_resume: str, processed_jd: str
    ) -> float:
        """
        Return a match score in the range [0, 100].

        Parameters
        ----------
        processed_resume : str
            Cleaned, tokenised resume text (space-separated tokens).
        processed_jd : str
            Cleaned, tokenised job-description text.

        Returns
        -------
        float
            Percentage match, e.g. 72.4
        """
        if not processed_resume or not processed_jd:
            return 0.0

        tfidf_score = self._tfidf_cosine(processed_resume, processed_jd)

        if self.mode == 'tfidf':
            return tfidf_score * 100

        # Hybrid: blend TF-IDF with a keyword-overlap feature
        overlap_score = self._token_overlap(processed_resume, processed_jd)
        length_score  = self._length_penalty(processed_resume, processed_jd)

        # Weighted blend
        blended = (
            tfidf_score   * 0.65 +
            overlap_score * 0.25 +
            length_score  * 0.10
        )
        return min(blended * 100, 100.0)

    # ── TF-IDF Cosine ─────────────────────────────────────────────────────────

    def _tfidf_cosine(self, text_a: str, text_b: str) -> float:
        """Cosine similarity between TF-IDF vectors of two documents."""
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity

            vectorizer = TfidfVectorizer(
                ngram_range=(1, 2),   # unigrams + bigrams
                min_df=1,
                sublinear_tf=True,
            )
            tfidf_matrix = vectorizer.fit_transform([text_a, text_b])
            score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return float(score)

        except ImportError:
            # scikit-learn not installed → fall back to manual cosine
            return self._manual_cosine(text_a, text_b)

    def _manual_cosine(self, text_a: str, text_b: str) -> float:
        """
        Manual TF cosine similarity (no external dependencies).
        Less accurate than TF-IDF but always available.
        """
        def tf_vector(text: str) -> dict:
            tokens = text.split()
            freq   = {}
            for t in tokens:
                freq[t] = freq.get(t, 0) + 1
            total = len(tokens) or 1
            return {k: v / total for k, v in freq.items()}

        vec_a = tf_vector(text_a)
        vec_b = tf_vector(text_b)

        all_keys = set(vec_a) | set(vec_b)
        dot      = sum(vec_a.get(k, 0) * vec_b.get(k, 0) for k in all_keys)
        norm_a   = math.sqrt(sum(v ** 2 for v in vec_a.values()))
        norm_b   = math.sqrt(sum(v ** 2 for v in vec_b.values()))

        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    # ── Supplementary Scoring Features ───────────────────────────────────────

    def _token_overlap(self, text_a: str, text_b: str) -> float:
        """Jaccard overlap of unique tokens (0–1)."""
        set_a = set(text_a.split())
        set_b = set(text_b.split())
        if not set_a or not set_b:
            return 0.0
        intersection = set_a & set_b
        union        = set_a | set_b
        return len(intersection) / len(union)

    def _length_penalty(self, text_a: str, text_b: str) -> float:
        """
        Rewards resumes that are not drastically shorter than the JD.
        Penalises very sparse resumes relative to a detailed JD.
        Returns a score in [0, 1].
        """
        len_a = len(text_a.split())
        len_b = len(text_b.split())
        if len_b == 0:
            return 1.0
        ratio = min(len_a / len_b, 1.0)
        # Soft sigmoid-like mapping: penalise if resume is < 30% of JD length
        if ratio >= 0.3:
            return 1.0
        return ratio / 0.3
