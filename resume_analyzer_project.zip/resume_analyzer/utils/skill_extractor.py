"""
utils/skill_extractor.py
========================
Identifies technical and soft skills in resume / job-description text.

Strategy:
  1. Keyword matching against a curated, categorised skills dictionary.
  2. Multi-word phrase matching (e.g. "machine learning", "rest api").
  3. Returns matched keywords for highlighting.
"""

import re
from typing import Dict, List, Set


# ── Comprehensive Skills Database ─────────────────────────────────────────────

SKILLS_DB: Dict[str, List[str]] = {
    # Programming Languages
    "Programming Languages": [
        "python", "java", "javascript", "typescript", "c++", "c#", "c", "ruby",
        "php", "swift", "kotlin", "go", "golang", "rust", "scala", "r",
        "perl", "matlab", "bash", "shell", "powershell", "lua", "dart",
        "objective-c", "assembly", "vba", "groovy", "elixir", "haskell",
        "clojure", "f#", "cobol", "fortran",
    ],

    # Web Frontend
    "Frontend": [
        "html", "css", "react", "reactjs", "react.js", "vue", "vuejs", "vue.js",
        "angular", "angularjs", "svelte", "nextjs", "next.js", "nuxt",
        "jquery", "bootstrap", "tailwind", "tailwindcss", "sass", "scss",
        "less", "webpack", "vite", "babel", "redux", "mobx", "graphql",
        "apollo", "gatsby", "remix", "astro", "stencil",
    ],

    # Backend & Frameworks
    "Backend": [
        "node", "nodejs", "node.js", "express", "expressjs", "fastapi",
        "flask", "django", "spring", "springboot", "spring boot", "laravel",
        "rails", "ruby on rails", "asp.net", "aspnet", "dotnet", ".net",
        "gin", "fiber", "nestjs", "nest.js", "strapi", "hapi", "koa",
        "phoenix", "play framework", "grpc", "rest api", "restful", "soap",
        "graphql api", "microservices", "websocket", "oauth", "jwt",
    ],

    # Databases
    "Databases": [
        "mysql", "postgresql", "postgres", "sqlite", "mongodb", "redis",
        "cassandra", "dynamodb", "elasticsearch", "firebase", "firestore",
        "oracle", "sql server", "mssql", "mariadb", "couchdb", "neo4j",
        "influxdb", "timescaledb", "cockroachdb", "snowflake", "bigquery",
        "hive", "hbase", "memcached",
    ],

    # Cloud & DevOps
    "Cloud & DevOps": [
        "aws", "azure", "gcp", "google cloud", "heroku", "digital ocean",
        "docker", "kubernetes", "k8s", "terraform", "ansible", "jenkins",
        "gitlab ci", "github actions", "circleci", "travis ci", "helm",
        "nginx", "apache", "linux", "unix", "vagrant", "chef", "puppet",
        "prometheus", "grafana", "elk stack", "logstash", "kibana",
        "cloudformation", "pulumi", "istio", "argocd", "datadog", "splunk",
    ],

    # Data Science & ML
    "Data Science & ML": [
        "machine learning", "deep learning", "neural networks", "nlp",
        "natural language processing", "computer vision", "data science",
        "data analysis", "data engineering", "pandas", "numpy", "scipy",
        "scikit-learn", "sklearn", "tensorflow", "pytorch", "keras",
        "xgboost", "lightgbm", "catboost", "hugging face", "transformers",
        "bert", "gpt", "llm", "rag", "langchain", "mlflow", "airflow",
        "spark", "pyspark", "hadoop", "tableau", "power bi", "matplotlib",
        "seaborn", "plotly", "dbt", "great expectations", "feature engineering",
        "a/b testing", "statistics", "probability", "linear algebra",
    ],

    # Mobile
    "Mobile": [
        "android", "ios", "react native", "flutter", "xamarin", "ionic",
        "cordova", "swiftui", "jetpack compose", "expo",
    ],

    # Version Control & Collaboration
    "Version Control": [
        "git", "github", "gitlab", "bitbucket", "svn", "mercurial",
        "jira", "confluence", "trello", "asana", "notion",
    ],

    # Testing
    "Testing": [
        "unit testing", "integration testing", "selenium", "pytest", "jest",
        "mocha", "chai", "cypress", "playwright", "junit", "testng",
        "robot framework", "postman", "insomnia", "tdd", "bdd", "qa",
        "load testing", "performance testing",
    ],

    # Security
    "Security": [
        "cybersecurity", "penetration testing", "ethical hacking", "owasp",
        "ssl", "tls", "encryption", "authentication", "authorization",
        "siem", "soc", "vulnerability assessment", "network security",
        "firewalls", "iam",
    ],

    # Project Management & Methodologies
    "Project Management": [
        "agile", "scrum", "kanban", "waterfall", "pmp", "prince2",
        "project management", "product management", "roadmap", "sprint",
        "retrospective", "stakeholder management", "risk management",
    ],

    # Soft Skills
    "Soft Skills": [
        "communication", "leadership", "teamwork", "problem solving",
        "critical thinking", "time management", "adaptability", "creativity",
        "collaboration", "mentoring", "presentation", "negotiation",
        "analytical", "detail oriented", "self motivated", "multitasking",
    ],

    # Architecture & Design
    "Architecture": [
        "system design", "distributed systems", "high availability",
        "scalability", "design patterns", "solid principles", "dry",
        "api design", "event driven", "cqrs", "ddd", "domain driven design",
        "serverless", "soa", "service oriented architecture",
    ],
}

# Flat set of all known skills (lowercase)
ALL_SKILLS: Set[str] = {
    skill.lower()
    for skills in SKILLS_DB.values()
    for skill in skills
}


class SkillExtractor:
    """Extracts, compares, and highlights skills in text."""

    def __init__(self):
        # Sort by length descending so longer phrases are matched first
        self._sorted_skills = sorted(ALL_SKILLS, key=len, reverse=True)

    # ── Public API ────────────────────────────────────────────────────────────

    def extract_skills(self, text: str) -> Set[str]:
        """
        Return the set of known skills found in *text*.
        Uses whole-word / phrase boundary matching to avoid false positives
        (e.g. "r" should not match inside "react").
        """
        if not text:
            return set()

        text_lower = text.lower()
        found: Set[str] = set()

        for skill in self._sorted_skills:
            # Build a regex that matches the skill as a whole word/phrase
            pattern = r'(?<![a-z0-9#+])' + re.escape(skill) + r'(?![a-z0-9#+])'
            if re.search(pattern, text_lower):
                found.add(skill)

        return found

    def find_missing_skills(
        self, resume_skills: Set[str], jd_skills: Set[str]
    ) -> Set[str]:
        """Skills present in the JD but absent from the resume."""
        return jd_skills - resume_skills

    def find_matched_skills(
        self, resume_skills: Set[str], jd_skills: Set[str]
    ) -> Set[str]:
        """Skills present in both the resume and the JD."""
        return resume_skills & jd_skills

    def get_keyword_highlights(
        self, resume_text: str, jd_skills: Set[str]
    ) -> Dict[str, bool]:
        """
        For each skill in the JD, indicate whether it appears in the resume.
        Returns {'python': True, 'docker': False, ...}
        """
        resume_lower = resume_text.lower()
        highlights: Dict[str, bool] = {}

        for skill in jd_skills:
            pattern = r'(?<![a-z0-9#+])' + re.escape(skill) + r'(?![a-z0-9#+])'
            highlights[skill] = bool(re.search(pattern, resume_lower))

        return highlights

    def get_skills_by_category(self, skills: Set[str]) -> Dict[str, List[str]]:
        """Group a flat set of skills back into their categories."""
        categorised: Dict[str, List[str]] = {}
        for category, category_skills in SKILLS_DB.items():
            matched = [s for s in category_skills if s.lower() in skills]
            if matched:
                categorised[category] = matched
        return categorised
