"""
utils/resume_parser.py
======================
Handles extraction of raw text from various resume file formats:
  - PDF  (via pdfplumber, with PyPDF2 fallback)
  - TXT  (plain text)
  - DOCX (via python-docx)
"""

import os
import re
from typing import Optional


class ResumeParser:
    """Extracts and lightly cleans text from resume files."""

    # ── Public API ────────────────────────────────────────────────────────────

    def extract_text(self, filepath: str) -> str:
        """
        Dispatch to the correct extractor based on file extension.

        Parameters
        ----------
        filepath : str
            Absolute or relative path to the resume file.

        Returns
        -------
        str
            Raw text content of the resume, or empty string on failure.
        """
        ext = os.path.splitext(filepath)[1].lower()

        extractors = {
            '.pdf':  self._extract_pdf,
            '.txt':  self._extract_txt,
            '.docx': self._extract_docx,
        }

        extractor = extractors.get(ext)
        if not extractor:
            raise ValueError(f"Unsupported file format: {ext}")

        text = extractor(filepath)
        return self._clean_raw_text(text)

    # ── Private Extractors ────────────────────────────────────────────────────

    def _extract_pdf(self, filepath: str) -> str:
        """
        Extract text from a PDF file.
        Tries pdfplumber first (better layout preservation),
        falls back to PyPDF2 if unavailable.
        """
        # Attempt 1: pdfplumber (preferred)
        try:
            import pdfplumber
            text_parts = []
            with pdfplumber.open(filepath) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
            if text_parts:
                return '\n'.join(text_parts)
        except ImportError:
            pass
        except Exception:
            pass

        # Attempt 2: PyPDF2 fallback
        try:
            import PyPDF2
            text_parts = []
            with open(filepath, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text = page.extract_text()
                    if text:
                        text_parts.append(text)
            return '\n'.join(text_parts)
        except ImportError:
            raise ImportError(
                "No PDF library found. Install pdfplumber: pip install pdfplumber"
            )
        except Exception as e:
            raise RuntimeError(f"PDF extraction failed: {e}")

    def _extract_txt(self, filepath: str) -> str:
        """Extract text from a plain-text file, trying common encodings."""
        encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252']
        for enc in encodings:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    return f.read()
            except (UnicodeDecodeError, FileNotFoundError):
                continue
        raise RuntimeError(f"Could not read text file with any supported encoding: {filepath}")

    def _extract_docx(self, filepath: str) -> str:
        """Extract text from a .docx Word document."""
        try:
            from docx import Document
            doc = Document(filepath)
            paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
            # Also extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            paragraphs.append(cell.text)
            return '\n'.join(paragraphs)
        except ImportError:
            raise ImportError(
                "python-docx not installed. Run: pip install python-docx"
            )
        except Exception as e:
            raise RuntimeError(f"DOCX extraction failed: {e}")

    # ── Text Cleaning ─────────────────────────────────────────────────────────

    def _clean_raw_text(self, text: str) -> str:
        """
        Light cleaning of extracted text:
          - Collapse excessive whitespace / blank lines
          - Remove non-printable characters
          - Normalise line endings
        """
        if not text:
            return ''

        # Normalise line endings
        text = text.replace('\r\n', '\n').replace('\r', '\n')

        # Remove non-printable / control characters (keep newlines/tabs)
        text = re.sub(r'[^\x09\x0A\x20-\x7E\u00A0-\uFFFF]', ' ', text)

        # Collapse 3+ consecutive blank lines into 2
        text = re.sub(r'\n{3,}', '\n\n', text)

        # Strip leading/trailing whitespace per line
        lines = [line.strip() for line in text.split('\n')]
        text  = '\n'.join(lines)

        return text.strip()
