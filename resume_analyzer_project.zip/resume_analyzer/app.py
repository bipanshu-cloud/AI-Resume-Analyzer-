"""
AI Resume Analyzer - Main Application
=====================================
Flask-based web application that analyzes resumes against job descriptions
using NLP and ML techniques to provide match scores and improvement suggestions.
"""

import os
import json
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from utils.resume_parser import ResumeParser
from utils.text_processor import TextProcessor
from utils.skill_extractor import SkillExtractor
from utils.similarity_engine import SimilarityEngine
from utils.suggestion_engine import SuggestionEngine

# ─── App Configuration ────────────────────────────────────────────────────────
app = Flask(__name__)
app.config['SECRET_KEY'] = 'resume-analyzer-secret-2024'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max upload
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'txt', 'docx'}

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ─── Initialize Engines ───────────────────────────────────────────────────────
resume_parser    = ResumeParser()
text_processor   = TextProcessor()
skill_extractor  = SkillExtractor()
similarity_engine = SimilarityEngine()
suggestion_engine = SuggestionEngine()


def allowed_file(filename: str) -> bool:
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Render the main landing page."""
    return render_template('index.html')


@app.route('/analyze', methods=['POST'])
def analyze():
    """
    Core analysis endpoint.
    Accepts a resume file (PDF/TXT) and a job description string,
    returns JSON with match score, missing skills, and suggestions.
    """
    try:
        # ── 1. Validate Inputs ────────────────────────────────────────────────
        job_description = request.form.get('job_description', '').strip()
        if not job_description:
            return jsonify({'error': 'Job description is required.'}), 400

        resume_text = ''

        # Handle file upload
        if 'resume_file' in request.files and request.files['resume_file'].filename:
            file = request.files['resume_file']
            if not allowed_file(file.filename):
                return jsonify({'error': 'Invalid file type. Use PDF, TXT, or DOCX.'}), 400

            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            resume_text = resume_parser.extract_text(filepath)

            # Clean up uploaded file after extraction
            try:
                os.remove(filepath)
            except OSError:
                pass

        # Handle pasted resume text
        elif 'resume_text' in request.form and request.form['resume_text'].strip():
            resume_text = request.form['resume_text'].strip()

        else:
            return jsonify({'error': 'Please upload a resume file or paste resume text.'}), 400

        if not resume_text:
            return jsonify({'error': 'Could not extract text from the resume. Try a text-based PDF.'}), 400

        # ── 2. Preprocess Texts ───────────────────────────────────────────────
        processed_resume = text_processor.preprocess(resume_text)
        processed_jd     = text_processor.preprocess(job_description)

        # ── 3. Extract Skills ─────────────────────────────────────────────────
        resume_skills = skill_extractor.extract_skills(resume_text)
        jd_skills     = skill_extractor.extract_skills(job_description)

        # ── 4. Compute Similarity Score ───────────────────────────────────────
        match_score = similarity_engine.compute_similarity(
            processed_resume, processed_jd
        )

        # ── 5. Detect Missing Skills ──────────────────────────────────────────
        missing_skills  = skill_extractor.find_missing_skills(resume_skills, jd_skills)
        matched_skills  = skill_extractor.find_matched_skills(resume_skills, jd_skills)

        # ── 6. Generate Suggestions ───────────────────────────────────────────
        suggestions = suggestion_engine.generate_suggestions(
            missing_skills, match_score, resume_text, job_description
        )

        # ── 7. Keyword Highlights ─────────────────────────────────────────────
        keyword_highlights = skill_extractor.get_keyword_highlights(
            resume_text, jd_skills
        )

        # ── 8. Build Response ─────────────────────────────────────────────────
        response = {
            'success': True,
            'match_score': round(match_score, 1),
            'match_grade': get_grade(match_score),
            'resume_skills': sorted(list(resume_skills)),
            'jd_skills': sorted(list(jd_skills)),
            'matched_skills': sorted(list(matched_skills)),
            'missing_skills': sorted(list(missing_skills)),
            'suggestions': suggestions,
            'keyword_highlights': keyword_highlights,
            'stats': {
                'resume_word_count': len(resume_text.split()),
                'jd_word_count': len(job_description.split()),
                'total_jd_skills': len(jd_skills),
                'matched_count': len(matched_skills),
                'missing_count': len(missing_skills),
            }
        }
        return jsonify(response)

    except Exception as e:
        app.logger.error(f"Analysis error: {str(e)}")
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@app.route('/analyze-multiple', methods=['POST'])
def analyze_multiple():
    """
    Bonus: Analyze multiple resumes against a single job description.
    Returns a ranked list of candidates.
    """
    try:
        job_description = request.form.get('job_description', '').strip()
        if not job_description:
            return jsonify({'error': 'Job description is required.'}), 400

        files = request.files.getlist('resumes')
        if not files or len(files) == 0:
            return jsonify({'error': 'No resume files provided.'}), 400

        processed_jd = text_processor.preprocess(job_description)
        jd_skills    = skill_extractor.extract_skills(job_description)
        results      = []

        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)

                resume_text = resume_parser.extract_text(filepath)
                try:
                    os.remove(filepath)
                except OSError:
                    pass

                if resume_text:
                    processed_resume = text_processor.preprocess(resume_text)
                    match_score      = similarity_engine.compute_similarity(
                        processed_resume, processed_jd
                    )
                    resume_skills   = skill_extractor.extract_skills(resume_text)
                    missing_skills  = skill_extractor.find_missing_skills(resume_skills, jd_skills)
                    matched_skills  = skill_extractor.find_matched_skills(resume_skills, jd_skills)

                    results.append({
                        'filename': filename,
                        'match_score': round(match_score, 1),
                        'match_grade': get_grade(match_score),
                        'matched_skills': sorted(list(matched_skills)),
                        'missing_skills': sorted(list(missing_skills)),
                    })

        # Rank by match score
        results.sort(key=lambda x: x['match_score'], reverse=True)
        return jsonify({'success': True, 'candidates': results})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/health')
def health():
    """Health check endpoint."""
    return jsonify({'status': 'healthy', 'version': '1.0.0'})


# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_grade(score: float) -> dict:
    """Convert a numeric score to a letter grade with color and label."""
    if score >= 80:
        return {'letter': 'A', 'label': 'Excellent Match',  'color': '#10b981'}
    elif score >= 65:
        return {'letter': 'B', 'label': 'Good Match',       'color': '#3b82f6'}
    elif score >= 50:
        return {'letter': 'C', 'label': 'Fair Match',       'color': '#f59e0b'}
    elif score >= 35:
        return {'letter': 'D', 'label': 'Poor Match',       'color': '#f97316'}
    else:
        return {'letter': 'F', 'label': 'Very Low Match',   'color': '#ef4444'}


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("🚀 AI Resume Analyzer starting...")
    print("📡 Visit: http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
